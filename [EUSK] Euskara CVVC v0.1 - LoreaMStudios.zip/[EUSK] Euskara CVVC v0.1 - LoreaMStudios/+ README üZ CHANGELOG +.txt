☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘

〇〇〇〇〇 README 〇〇〇〇〇

NO VOICE LIBRARY HAS BEEN RECORDED YET, USE AT YOUR
OWN RISK


This method belongs to LoreaMStudios. Basque (Euskara)
is a language spoken in the north regions of Spain.
Phonetically wise, it's super similar to spanish,
if you have a base idea of spanish, this shouldn't
be more difficult than a CVVC spanish voicebank.

More info about Euskara: https://theculturetrip.com/europe/spain/articles/basque-language-everything-you-need-to-know/

Please state my username (@LoreaMStudios) somewhere
on your voicebank or socials if you use this reclist.


I only ask to not redestribute the raw materials, in any shape
and form. However, edited and modified reclists are not included
in this prohibition (you are allowed to freely distribute them, as
long as you state my user, too).



〇〇〇〇〇〇〇〇〇〇〇〇〇〇〇〇〇〇〇


	* LOG ORDER: *


Older ->> Recent


☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘☆彡✘



✘> 22/06/2022 > v0.1

〇 >> DONE
× >> PROGRESS
●　>> NOT DONE YET

> Sound guide explanations:　〇
> Reclist revision: 〇
> oto revision: ●
> UST addition: ●

